from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import os
from nlp_processor import NLPProcessor

# Set up the paths to the static and template folders outside the backend folder
app = Flask(__name__, 
            static_folder=os.path.join(os.path.abspath(os.path.dirname(__file__)), '../static'),
            template_folder=os.path.join(os.path.abspath(os.path.dirname(__file__)), '../templates'))

# Enable CORS
CORS(app)

# Initialize NLP processor
nlp_processor = NLPProcessor()

@app.route('/')
def index():
    """Serve the main application page"""
    return render_template('index.html')

@app.route('/recognize-intent', methods=['POST'])
def recognize_intent():
    data = request.get_json()
    message = data.get('message', '')
    
    if not message:
        return jsonify({'error': 'No message provided'}), 400
    
    # Process the message
    intent, confidence = nlp_processor.process_message(message)
    
    # Generate appropriate response
    response = generate_response(intent, message)
    
    return jsonify({
        'intent': intent,
        'confidence': float(confidence),
        'response': response
    })

def generate_response(intent, message):
    """Generate an appropriate response based on the recognized intent"""
    intent_responses = {
        'greeting': "Hello! How can I assist you today?",
        'farewell': "Goodbye! Have a great day!",
        'weather': "weather is too hottt !!.",
        'time': "I can tell you the time. The current time is not available in this demo.",
        'joke': "Why don't scientists trust atoms? Because they make up everything!",
        'news': "I can fetch the latest news for you.",
        'help': "I can help with various tasks like telling time, weather, jokes, or news. Just ask!",
        'unknown': "I'm not sure I understand. Can you rephrase or ask something else?"
    }
    
    return intent_responses.get(intent, intent_responses['unknown'])

if __name__ == '__main__':
    app.run(debug=True)

