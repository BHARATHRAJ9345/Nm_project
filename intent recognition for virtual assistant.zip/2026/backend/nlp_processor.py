import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import json
import re
import os

class NLPProcessor:
    def __init__(self):
        self.intents = self.load_intents()
        self.vectorizer = TfidfVectorizer()
        self.prepare_data()
    
    def load_intents(self):
        """Load intents from JSON file"""
        # Get the absolute path to the intents.json file for better reliability
        current_dir = os.path.dirname(os.path.abspath(__file__))
        intents_path = os.path.join(current_dir, '../intents.json')
        
        with open(intents_path, 'r') as file:
            return json.load(file)
    
    def prepare_data(self):
        """Prepare data for vectorization"""
        self.patterns = []
        self.labels = []
        
        for intent in self.intents['intents']:
            for pattern in intent['patterns']:
                self.patterns.append(self.preprocess_text(pattern))
                self.labels.append(intent['tag'])
        
        # Train the vectorizer
        self.X = self.vectorizer.fit_transform(self.patterns)
    
    def preprocess_text(self, text):
        """Basic text preprocessing"""
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)
        return text
    
    def process_message(self, message):
        """Process a message and return the most likely intent"""
        processed_msg = self.preprocess_text(message)
        msg_vec = self.vectorizer.transform([processed_msg])
        
        # Calculate similarity with all patterns
        similarities = cosine_similarity(msg_vec, self.X)
        max_sim_idx = np.argmax(similarities)
        max_sim = similarities[0, max_sim_idx]
        
        # Get the corresponding intent
        intent = self.labels[max_sim_idx]
        
        # Apply a confidence threshold
        confidence_threshold = 0.5
        if max_sim < confidence_threshold:
            intent = 'unknown'
            max_sim = 0.0
        
        return intent, max_sim
