document.addEventListener('DOMContentLoaded', function() {
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    const chatHistory = document.getElementById('chatHistory');
    const intentInfo = document.getElementById('intentInfo');
    
    // Handle sending messages
    function sendMessage() {
        const message = userInput.value.trim();
        if (message === '') return;
        
        // Add user message to chat
        addMessageToChat(message, 'user');
        userInput.value = '';
        
        // Show typing indicator
        const typingIndicator = addTypingIndicator();
        
        // Send to backend for processing
        recognizeIntent(message)
            .then(response => {
                // Remove typing indicator
                chatHistory.removeChild(typingIndicator);
                
                // Add assistant response
                addMessageToChat(response.response, 'assistant');
                
                // Update intent display
                updateIntentDisplay(response.intent, response.confidence);
            })
            .catch(error => {
                console.error('Error:', error);
                chatHistory.removeChild(typingIndicator);
                addMessageToChat("Sorry, I encountered an error processing your request.", 'assistant');
                intentInfo.innerHTML = '<p>Error recognizing intent</p>';
            });
    }
    
    // Add message to chat history
    function addMessageToChat(message, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `${sender}-message`;
        
        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'avatar';
        avatarDiv.textContent = sender === 'assistant' ? 'VA' : 'You';
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        contentDiv.textContent = message;
        
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);
        
        if (sender === 'user') {
            // For user messages, avatar comes after content
            messageDiv.insertBefore(contentDiv, avatarDiv);
        }
        
        chatHistory.appendChild(messageDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }
    
    // Add typing indicator
    function addTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'assistant-message';
        
        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'avatar';
        avatarDiv.textContent = 'VA';
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content typing-indicator';
        
        // Create three dots for typing effect
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('span');
            dot.className = 'dot';
            contentDiv.appendChild(dot);
        }
        
        typingDiv.appendChild(avatarDiv);
        typingDiv.appendChild(contentDiv);
        chatHistory.appendChild(typingDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;
        
        return typingDiv;
    }
    
    // Update intent display
    function updateIntentDisplay(intent, confidence) {
        intentInfo.innerHTML = `
            <p><strong>Intent:</strong> ${intent}</p>
            <p class="confidence"><strong>Confidence:</strong> ${(confidence * 100).toFixed(2)}%</p>
        `;
    }
    
    // Send message to backend for intent recognition
    async function recognizeIntent(message) {
        const response = await fetch('/recognize-intent', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message }),
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        return await response.json();
    }
    
    // Event listeners
    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});
